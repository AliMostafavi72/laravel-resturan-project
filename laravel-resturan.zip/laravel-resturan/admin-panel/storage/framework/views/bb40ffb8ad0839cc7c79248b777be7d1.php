<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="fw-bold">سفارشات</h4>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>شماره سفارش</th>
                <th>آدرس</th>
                <th>وضعیت</th>
                <th>وضعیت پرداخت</th>
                <th>قیمت کل</th>
                <th>تاریخ</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>
                        <?php echo e($order->id); ?>

                    </th>
                    <td><?php echo e($order->address->title); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td>
                            <span
                                class="<?php echo e($order->getRawOriginal('payment_status') ? 'text-success' : 'text-danger'); ?>"><?php echo e($order->payment_status); ?>

                            </span>
                    </td>
                    <td><?php echo e(number_format($order->paying_amount)); ?> تومان</td>
                    <td><?php echo e(verta($order->created_at)->format('%B %d، %Y')); ?></td>
                    <td>
                        <div class="d-flex">
                            <div>
                                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#modal-<?php echo e($order->id); ?>">
                                    محصولات
                                </button>

                                <div class="modal fade" id="modal-<?php echo e($order->id); ?>">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title">محصولات سفارش
                                                    شماره <?php echo e($order->id); ?></h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <table class="table align-middle">
                                                    <thead>
                                                    <tr>
                                                        <th>محصول</th>
                                                        <th>نام</th>
                                                        <th>قیمت</th>
                                                        <th>تعداد</th>
                                                        <th>قیمت کل</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__currentLoopData = $order->orderItems()->with('product')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <th>
                                                                <img class="rounded"
                                                                     src="<?php echo e(asset('images/products/' . $item->product->primary_image)); ?>"
                                                                     width="80" alt="" />
                                                            </th>
                                                            <td class="fw-bold"><?php echo e($item->product->name); ?></td>
                                                            <td><?php echo e($item->price); ?> تومان</td>
                                                            <td>
                                                                <?php echo e($item->quantity); ?>

                                                            </td>
                                                            <td><?php echo e(number_format($item->subtotal)); ?> تومان</td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="btn btn-sm btn-outline-info ms-2">ویرایش</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($orders->links('layout.paginate')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-admin-panel\lara-admin\resources\views/orders/index.blade.php ENDPATH**/ ?>