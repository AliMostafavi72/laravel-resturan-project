<?php $__env->startSection('title', 'Profile Page'); ?>

<?php $__env->startSection('content'); ?>
    <section class="profile_section layout_padding">
        <div class="container">
            <div class="row">
               <?php echo $__env->make('profile.layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php echo $__env->yieldContent('main'); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/profile/layout/master.blade.php ENDPATH**/ ?>