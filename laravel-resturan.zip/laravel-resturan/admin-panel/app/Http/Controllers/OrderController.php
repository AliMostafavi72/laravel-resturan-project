<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::latest('created_at')->with(['address', 'orderItems'])->paginate(3);
//       dd($orders);
        return view('orders.index', compact('orders'));
    }
}
