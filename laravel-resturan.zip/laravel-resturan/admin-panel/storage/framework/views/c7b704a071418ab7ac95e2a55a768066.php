<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-right',
        iconColor: 'white',
        customClass: {
            popup: 'colored-toast',
        },
        showConfirmButton: false,
        timer: 5000,
        timerProgressBar: true,
    })

    <?php if(session('success')): ?>
    Toast.fire({
        icon: 'success',
        title: '<?php echo e(session('success')); ?>',
    })
    <?php elseif(session('error')): ?>
    Toast.fire({
        icon: 'error',
        title: '<?php echo e(session('error')); ?>',
    })
    <?php elseif(session('warning')): ?>
    Toast.fire({
        icon: 'warning',
        title: '<?php echo e(session('warning')); ?>',
    })
    <?php endif; ?>
</script>

<?php echo $__env->yieldContent('script'); ?>


</body>
</html>
<?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-admin-panel\lara-admin\resources\views/layout/footer.blade.php ENDPATH**/ ?>