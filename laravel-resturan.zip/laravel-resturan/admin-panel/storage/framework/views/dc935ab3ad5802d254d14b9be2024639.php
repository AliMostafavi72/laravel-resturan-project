<?php $__env->startSection('title', 'Transactions'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="fw-bold">تراکنش ها</h4>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>شماره سفارش</th>
                <th>مبلغ</th>
                <th>وضعیت</th>
                <th>شماره پیگیری</th>
                <th>تاریخ</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>
                        <?php echo e($transaction->order_id); ?>

                    </th>
                    <td><?php echo e(number_format($transaction->amount)); ?> تومان</td>
                    <td>
                            <span
                                class="<?php echo e($transaction->getRawOriginal('status') ? 'text-success' : 'text-danger'); ?>"><?php echo e($transaction->status); ?></span>
                    </td>
                    <td><?php echo e($transaction->ref_number); ?></td>
                    <td><?php echo e(verta($transaction->created_at)->format('%B %d، %Y')); ?></td>
                    <td>
                        <a href="#" class="btn btn-sm btn-outline-info ms-2">ویرایش</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($transactions->links('layout.paginate')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-admin-panel\lara-admin\resources\views/transactions/index.blade.php ENDPATH**/ ?>