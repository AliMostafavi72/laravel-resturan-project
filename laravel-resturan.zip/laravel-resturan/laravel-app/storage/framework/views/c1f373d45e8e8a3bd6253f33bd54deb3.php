<form action="<?php echo e(route('contact.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div>
        <input name="name" type="text" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="نام و نام خانوادگی" />
        <div class="form-text text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
    </div>
    <div>
        <input name="email" type="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="ایمیل" />
        <div class="form-text text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
    </div>
    <div>
        <input name="subject" type="text" value="<?php echo e(old('subject')); ?>" class="form-control" placeholder="موضوع پیام" />
        <div class="form-text text-danger"><?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
    </div>
    <div>
        <textarea name="body" rows="10" style="height: 100px" class="form-control" placeholder="متن پیام"><?php echo e(old('body')); ?></textarea>
        <div class="form-text text-danger"><?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
    </div>
    <div class="btn_box">
        <button type="submit">
            ارسال پیام
        </button>
    </div>
</form>
<?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/components/contact/form.blade.php ENDPATH**/ ?>