<?php $__env->startSection('title', 'Profile Page'); ?>

<?php $__env->startSection('main'); ?>
    <div class="col-sm-12 col-lg-9">
        <a href="<?php echo e(route('profile.address.create')); ?>" class="btn btn-primary mb-4">
            ایجاد آدرس جدید
        </a>

        <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card card-body">
                <div class="row g-4">
                    <div class="col col-md-6">
                        <label class="form-label">عنوان</label>
                        <input disabled type="text" value="<?php echo e($address->title); ?>" class="form-control" />
                    </div>
                    <div class="col col-md-6">
                        <label class="form-label">شماره تماس</label>
                        <input disabled type="text" value="<?php echo e($address->cellphone); ?>" class="form-control" />
                    </div>
                    <div class="col col-md-6">
                        <label class="form-label">کد پستی</label>
                        <input disabled type="text" value="<?php echo e($address->postal_code); ?>" class="form-control" />
                    </div>
                    <div class="col col-md-6">
                        <label class="form-label">استان</label>
                        <input disabled type="text" value="<?php echo e($address->province->name); ?>" class="form-control" />
                    </div>
                    <div class="col col-md-6">
                        <label class="form-label">شهر</label>
                        <input disabled type="text" value="<?php echo e($address->city->name); ?>" class="form-control" />
                    </div>
                    <div class="col col-md-12">
                        <label class="form-label">آدرس</label>
                        <textarea disabled type="text" rows="5" class="form-control"><?php echo e($address->address); ?></textarea>
                    </div>
                </div>

                <div class="mt-4">
                    <a href="<?php echo e(route('profile.address.edit', ['address' => $address->id])); ?>"
                       class="btn btn-primary">ویرایش</a>
                </div>
            </div>
            <hr />
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/profile/addresses/index.blade.php ENDPATH**/ ?>