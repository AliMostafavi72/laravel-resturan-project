<?php $__env->startSection('title', 'Profile Page'); ?>

<?php $__env->startSection('main'); ?>
    <div class="col-sm-12 col-lg-9">
        <form action="<?php echo e(route('profile.update', ['user' => $user->id])); ?>" method="POST" class="vh-70">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row g-4">
                <div class="col col-md-6">
                    <label class="form-label">نام و نام خانوادگی</label>
                    <input name="name" type="text" class="form-control" value="<?php echo e($user->name); ?>"/>
                    <div class="form-text text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                </div>
                <div class="col col-md-6">
                    <label class="form-label">ایمیل</label>
                    <input name="email" type="text" class="form-control" value="<?php echo e($user-> email); ?>"/>
                    <div class="form-text text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                </div>
                <div class="col col-md-6">
                    <label class="form-label">شماره تلفن</label>
                    <input type="text" disabled class="form-control" value="<?php echo e($user->cellphone); ?>"/>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-4">ویرایش</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/profile/index.blade.php ENDPATH**/ ?>