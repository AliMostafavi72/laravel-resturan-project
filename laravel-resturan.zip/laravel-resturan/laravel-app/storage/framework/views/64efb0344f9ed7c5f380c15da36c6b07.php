
<section class="book_section layout_padding">
    <div class="container">
        <div class="heading_container">
            <h2>
                تماس با ما
            </h2>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form_container">

                    <?php if (isset($component)) { $__componentOriginal18bbd8166eb0a2655b01e28150aabfb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18bbd8166eb0a2655b01e28150aabfb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact.form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18bbd8166eb0a2655b01e28150aabfb1)): ?>
<?php $attributes = $__attributesOriginal18bbd8166eb0a2655b01e28150aabfb1; ?>
<?php unset($__attributesOriginal18bbd8166eb0a2655b01e28150aabfb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18bbd8166eb0a2655b01e28150aabfb1)): ?>
<?php $component = $__componentOriginal18bbd8166eb0a2655b01e28150aabfb1; ?>
<?php unset($__componentOriginal18bbd8166eb0a2655b01e28150aabfb1); ?>
<?php endif; ?>

                </div>
            </div>
            <div class="col-md-6">
                <div class="map_container ">
                    <div id="map" style="height: 345px;"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/home/contact.blade.php ENDPATH**/ ?>