<?php $__env->startSection('title', 'Menu Page'); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        document.addEventListener('alpine:init', () => {
            Alpine.data('filter', () => ({
                search: '',
                currentUrl: '<?php echo e(url()->current()); ?>',
                params: new URLSearchParams(location.search),

                filter(type, value) {
                    this.params.set(type, value);
                    this.params.delete('page');
                    document.location.href = this.currentUrl + '?' + this.params.toString();
                },

                removeFilter(type) {
                    this.params.delete(type);
                    this.params.delete('page');
                    document.location.href = this.currentUrl + '?' + this.params.toString();
                }
            }))
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="food_section layout_padding">
        <div class="container">
            <div class="row">
                <div x-data="filter" class="col-sm-12 col-lg-3">
                    <div>
                        <label class="form-label">جستجو
                            <?php if(request()->has('search')): ?>
                                <i @click="removeFilter('search')" class="bi bi-x text-danger fs-5 cursor-pointer"></i>
                            <?php endif; ?>
                        </label>

                        <div class="input-group mb-3">
                            <input type="text" x-model="search" class="form-control" placeholder="نام محصول ..." />
                            <button @click="filter('search', search)" class="input-group-text">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                    <hr />
                    <div class="filter-list">
                        <div class="form-label">
                            دسته بندی
                            <?php if(request()->has('category')): ?>
                                <i @click="removeFilter('category')" class="bi bi-x text-danger fs-5 cursor-pointer"></i>
                            <?php endif; ?>
                        </div>
                        <ul>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li @click="filter('category', '<?php echo e($category->id); ?>')"
                                    class="my-2 cursor-pointer
                                <?php echo e(request()->has('category') && request()->category == $category->id ? 'filter-list-active' : ''); ?>

                                        "><?php echo e($category->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <hr />
                    <div>
                        <label class="form-label">مرتب سازی
                            <?php if(request()->has('sortBy')): ?>
                                <i @click="removeFilter('sortBy')" class="bi bi-x text-danger fs-5 cursor-pointer"></i>
                            <?php endif; ?>
                        </label>
                        <div class="form-check my-2">
                            <input @change="filter('sortBy', 'max')"
                                   <?php echo e(request()->has('sortBy') && request()->sortBy == 'max' ? 'checked' : ''); ?>

                                   class="form-check-input" type="radio" name="flexRadioDefault" />
                            <label class="form-check-label cursor-pointer">
                                بیشترین قیمت
                            </label>
                        </div>
                        <div class="form-check my-2">
                            <input @change="filter('sortBy', 'min')"
                                   <?php echo e(request()->has('sortBy') && request()->sortBy == 'min' ? 'checked' : ''); ?>

                                   class="form-check-input" type="radio" name="flexRadioDefault"  />
                            <label class="form-check-label cursor-pointer">
                                کمترین قیمت
                            </label>
                        </div>
                        <div class="form-check my-2">
                            <input @change="filter('sortBy', 'bestseller')"
                                   <?php echo e(request()->has('sortBy') && request()->sortBy == 'bestseller' ? 'checked' : ''); ?>

                                   class="form-check-input" type="radio" name="flexRadioDefault" />
                            <label class="form-check-label cursor-pointer">
                                پرفروش ترین
                            </label>
                        </div>
                        <div class="form-check my-2">
                            <input @change="filter('sortBy', 'sale')"
                                   <?php echo e(request()->has('sortBy') && request()->sortBy == 'sale' ? 'checked' : ''); ?>

                                   class="form-check-input" type="radio" name="flexRadioDefault" />
                            <label class="form-check-label cursor-pointer">
                                با تخفیف
                            </label>
                        </div>
                    </div>
                </div>

                <div class="col-sm-12 col-lg-9">
                    <?php if($products->isEmpty()): ?>
                        <div class="d-flex justify-content-center align-items-center h-100">
                            <h5>محصولی یافت نشده!</h5>
                        </div>
                    <?php endif; ?>

                    <div class="row gx-3">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-lg-4">
                                <div class="box">
                                    <div>
                                        <div class="img-box">
                                            <img class="img-fluid" src="<?php echo e(imageUrl($product->primary_image)); ?>"
                                                 alt="">
                                        </div>
                                        <div class="detail-box">
                                            <h5>
                                                <a href="<?php echo e(route('product.show', ['product' => $product->slug])); ?>">
                                                    <?php echo e($product->name); ?>

                                                </a>
                                            </h5>
                                            <p>
                                                <?php echo e($product->description); ?>

                                            </p>

                                            <div class="options">
                                                <?php if($product->is_sale): ?>
                                                    <h6>
                                                        <del><?php echo e(number_format($product->price)); ?></del>
                                                        <span>
                                                            <span
                                                                class="text-danger">(<?php echo e(salePercent($product->price, $product->sale_price)); ?>%)</span>
                                                            <?php echo e(number_format($product->sale_price)); ?>

                                                            <span>تومان</span>
                                                        </span>
                                                    </h6>
                                                <?php else: ?>
                                                    <h6>
                                                        <?php echo e(number_format($product->price)); ?>

                                                        <span>تومان</span>
                                                    </h6>
                                                <?php endif; ?>

                                                <div class="d-flex">
                                                    <a class="me-2" href="<?php echo e(route('cart.increment', ['product_id' => $product->id , 'qty' => 1])); ?>">
                                                        <i class="bi bi-cart-fill text-white fs-6"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('profile.wishlist.add', ['product_id' => $product->id ])); ?>">
                                                        <i class="bi bi-heart-fill text-white fs-6"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php echo e($products->withQueryString()->links('layout.paginate')); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/products/menu.blade.php ENDPATH**/ ?>