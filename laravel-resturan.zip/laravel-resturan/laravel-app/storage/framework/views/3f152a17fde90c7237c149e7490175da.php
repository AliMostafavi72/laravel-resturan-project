<?php $__env->startSection('title', 'Cart Page'); ?>


<?php $__env->startSection('content'); ?>

    <?php if($cart == null): ?>
        <div class="cart-empty">
            <div class="text-center">
                <div>
                    <i class="bi bi-basket-fill" style="font-size:80px"></i>
                </div>
                <h4 class="text-bold">سبد خرید شما خالی است</h4>
                <a href="<?php echo e(route('product.menu')); ?>" class="btn btn-outline-dark mt-3">
                    مشاهده محصولات
                </a>
            </div>
        </div>
    <?php else: ?>

        <section class="single_page_section layout_padding">
            <div x-data="{addressId: null}" class="container">
                <div class="row">
                    <div class="col-md-10 offset-md-1">
                        <div class="row gy-5">
                            <div class="col-12">
                                <div class="table-responsive">
                                    <table class="table align-middle">
                                        <thead>
                                        <tr>
                                            <th>محصول</th>
                                            <th>نام</th>
                                            <th>قیمت</th>
                                            <th>تعداد</th>
                                            <th>قیمت کل</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th>
                                                    <img class="rounded" src="<?php echo e(imageUrl($item['primary_image'])); ?>"
                                                         width="100" alt=""/>
                                                </th>
                                                <td class="fw-bold"><?php echo e($item['name']); ?></td>
                                                <td>
                                                    <?php if($item['is_sale']): ?>
                                                        <div>
                                                            <del><?php echo e(number_format($item['price'])); ?></del>
                                                            <?php echo e(number_format($item['sale_price'])); ?>

                                                            تومان
                                                        </div>
                                                        <div class="text-danger">
                                                            <?php echo e(salePercent($item['price'], $item['sale_price'])); ?>%
                                                            تخفیف
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <?php echo e(number_format($item['price'])); ?>

                                                            تومان
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="input-counter">
                                                        <a href="<?php echo e(route('cart.increment', ['product_id' => $key, 'qty' => 1])); ?>"
                                                           class="plus-btn">
                                                            +
                                                        </a>
                                                        <div class="input-number"><?php echo e($item['qty']); ?></div>
                                                        <a href="<?php echo e(route('cart.decrement', ['product_id' => $key,'qty' => $item['qty'] - 1] )); ?>"
                                                           class="minus-btn">
                                                            -
                                                        </a>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php
                                                        $price = $item['is_sale'] ? $item['sale_price'] : $item['price'];
                                                    ?>
                                                    <span><?php echo e(number_format($item['qty'] * $price)); ?></span>
                                                    <span class="ms-1">تومان</span>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('cart.remove', ['product_id' => $key])); ?>">
                                                        <i class="bi bi-x text-danger fw-bold fs-4 cursor-pointer"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                                <a href="<?php echo e(route('cart.clear')); ?>" class="btn btn-primary mb-4">پاک کردن سبد خرید</a>
                            </div>
                        </div>

                        <div class="row mt-4">
                            <div class="col-12 col-md-6">
                                <form action="<?php echo e(route('cart.checkCoupon')); ?>">
                                    <div class="input-group mb-3">
                                        <input name="code" type="text" class="form-control" placeholder="کد تخفیف"/>
                                        <button type="submit" class="input-group-text" id="basic-addon2">اعمال کد
                                            تخفیف
                                        </button>
                                        <div class="form-text text-danger"><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                                    </div>
                                </form>
                            </div>

                            <div class="col-12 col-md-6 d-flex justify-content-end align-items-baseline">
                                <?php if($addresses->isEmpty()): ?>
                                    <a href="<?php echo e(route('profile.address.create')); ?>" class="btn btn-primary">
                                        ایجاد آدرس
                                    </a>
                                <?php else: ?>
                                    <div>
                                        انتخاب آدرس
                                    </div>
                                    <select x-model="addressId" style="width: 200px;" class="form-select ms-3">
                                        <option value="">انتخاب آدرس</option>
                                        <?php $__currentLoopData = @$addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($address->id); ?>"><?php echo e($address->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="form-text text-danger"><?php $__errorArgs = ['address_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="row justify-content-center mt-5">
                            <div class="col-12 col-md-6">
                                <div class="card">
                                    <div class="card-body p-4">
                                        <h5 class="card-title fw-bold">مجموع سبد خرید</h5>
                                        <ul class="list-group mt-4">
                                            <li class="list-group-item d-flex justify-content-between">
                                                <div>مجموع قیمت :</div>
                                                <div>
                                                    <?php echo e(number_format($cart_total_price)); ?> تومان
                                                </div>
                                            </li>

                                            <?php
                                                $couponPrice = 0;
                                                if(request()->session()->has('coupon')) {
                                                 $coupon = request()->session()->get('coupon');
                                                 $couponCode = $coupon['code'];
                                                 $couponPercent = $coupon['percent'];
                                                 $couponPrice = ($cart_total_price * $couponPercent) / 100;
                                                 }
                                            ?>

                                            <?php if($couponPrice != 0): ?>
                                                <li class="list-group-item d-flex justify-content-between">
                                                    <div>تخفیف :
                                                        <span class="text-danger ms-1"><?php echo e($couponPercent); ?></span>
                                                    </div>
                                                    <div class="text-danger">
                                                        <?php echo e(number_format($couponPrice)); ?> تومان
                                                    </div>
                                                </li>
                                            <?php endif; ?>

                                            <li class="list-group-item d-flex justify-content-between">
                                                <div>قیمت پرداختی :</div>
                                                <div>
                                                    <?php if($couponPrice != 0): ?>
                                                        <?php echo e(number_format($cart_total_price - $couponPrice)); ?>

                                                    <?php else: ?>
                                                        <?php echo e(number_format($cart_total_price)); ?>

                                                    <?php endif; ?>
                                                    تومان
                                                </div>
                                            </li>
                                        </ul>
                                      <form action="<?php echo e(route('payment.send')); ?>" method="POST">
                                          <?php echo csrf_field(); ?>
                                           <input name="coupon_code" value="<?php echo e($couponPrice !=0 ? $couponCode : null); ?>" type="hidden" />
                                          <input name="address_id" :value="addressId" type="hidden" />
                                          <button type="submit" class="user_option btn-auth mt-4">پرداخت</button>
                                      </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/cart/index.blade.php ENDPATH**/ ?>