<div class="col-sm-12 col-lg-3">
    <ul class="list-group">
        <li class="list-group-item">
            <a href="{{route('profile.index')}}">اطلاعات کاربر</a>
        </li>
        <li class="list-group-item">
            <a href="{{route('profile.address')}}">آدرس ها</a>
        </li>
        <li class="list-group-item">
            <a href="{{route('profile.order')}}">سفارشات</a>
        </li>
        <li class="list-group-item">
            <a href="{{route('profile.transaction')}}">تراکنش ها</a>
        </li>
        <li class="list-group-item">
            <a href="{{ route('profile.wishlist') }}">لیست علاقه مندی ها</a>
        </li>
        <li class="list-group-item">
            <a href="{{ route('auth.logout') }}">خروج</a>
        </li>
    </ul>
</div>
