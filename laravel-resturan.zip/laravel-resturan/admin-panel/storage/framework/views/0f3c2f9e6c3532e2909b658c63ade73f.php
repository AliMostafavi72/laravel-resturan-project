<?php $__env->startSection('title', 'Coupon'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="fw-bold">کد تخفیف</h4>
        <a href="<?php echo e(route('coupon.create')); ?>" class="btn btn-sm btn-outline-primary">ایجاد کد تخفیف</a>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>کد</th>
                <th>درصد تخفیف</th>
                <th>تاریخ انقضا</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($coupon->code); ?></td>
                    <td><?php echo e($coupon->percentage); ?></td>
                    <td><?php echo e(getJalaliDate($coupon->expired_at)); ?></td>

                    <td>
                        <div class="d-flex">
                            <a href="<?php echo e(route('coupon.edit', ['coupon' => $coupon->id])); ?>"
                               class="btn btn-sm btn-outline-info me-2">ویرایش</a>

                            <form action="<?php echo e(route('coupon.destroy', ['coupon' => $coupon->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">حذف</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-admin-panel\lara-admin\resources\views/coupons/index.blade.php ENDPATH**/ ?>