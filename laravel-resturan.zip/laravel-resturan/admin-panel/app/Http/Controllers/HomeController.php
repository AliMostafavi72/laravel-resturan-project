<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;
use Carbon\Carbon; // وارد کردن Carbon برای کار با تاریخ‌ها

class HomeController extends Controller
{
    public function index()
    {
        $month = 12; // تعداد ماه‌ها
        $successTransactions = Transaction::getData($month, 1)->get(); // دریافت رکوردهای موفق

        // پردازش داده‌ها برای ایجاد نمودار
        $successTransactionsChart = $this->chartData($successTransactions, $month);

        return view('dashboard', compact('successTransactionsChart'));
    }

    public function chartData($transactions, $month)
    {
        // گروه‌بندی تراکنش‌ها بر اساس ماه و سال
        $result = $transactions->groupBy(function($item) {
            return Carbon::parse($item->created_at)->format('Y-m'); // گروه‌بندی بر اساس سال و ماه
        })->map(function ($monthGroup) {
            return $monthGroup->sum('amount'); // جمع مقادیر در هر گروه
        });

        // ایجاد آرایه برای ماه‌های خالی
        $shamsiMonths = [];
        for ($i = 0; $i < $month; $i++) {
            $monthName = verta()->subMonths($i)->format('%B %Y');
            $shamsiMonths[$monthName] = 0; // مقدار 0 برای هر ماه
        }

        // ترکیب نتایج با ماه‌های خالی
        $data = array_merge($shamsiMonths, $result->toArray());

        // ایجاد finalResult
        $finalResult = [];
        foreach ($data as $month => $val) {
            array_push($finalResult, ['month' => $month, 'value' => $val]);
        }

        return $finalResult;
    }
}
