<?php $__env->startSection('title', 'Contact Us Show'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="fw-bold">نماش پیام ارتباط با ما</h4>
    </div>

    <form class="row gy-4">
        <div class="col-md-6">
            <label class="form-label">نام</label>
            <input disabled value="<?php echo e($message->name); ?>" class="form-control" />
        </div>
        <div class="col-md-3">
            <label class="form-label">ایمیل</label>
            <input disabled value="<?php echo e($message->email); ?>" class="form-control" />
        </div>
        <div class="col-md-3">
            <label class="form-label">موضوع پیام</label>
            <input disabled value="<?php echo e($message->subject); ?>" class="form-control" />
        </div>
        <div class="col-md-12">
            <label class="form-label">متن پیام</label>
            <textarea disabled class="form-control" rows="3"><?php echo e($message->body); ?></textarea>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-admin-panel\lara-admin\resources\views/contact/show.blade.php ENDPATH**/ ?>