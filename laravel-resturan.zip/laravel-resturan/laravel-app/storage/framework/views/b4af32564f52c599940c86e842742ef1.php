<div class="col-sm-12 col-lg-3">
    <ul class="list-group">
        <li class="list-group-item">
            <a href="<?php echo e(route('profile.index')); ?>">اطلاعات کاربر</a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('profile.address')); ?>">آدرس ها</a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('profile.order')); ?>">سفارشات</a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('profile.transaction')); ?>">تراکنش ها</a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('profile.wishlist')); ?>">لیست علاقه مندی ها</a>
        </li>
        <li class="list-group-item">
            <a href="<?php echo e(route('auth.logout')); ?>">خروج</a>
        </li>
    </ul>
</div>
<?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/profile/layout/sidebar.blade.php ENDPATH**/ ?>