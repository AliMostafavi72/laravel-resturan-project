<?php $__env->startSection('title', 'Sliders'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="fw-bold">اسلایدرها</h4>
        <a href="<?php echo e(route('slider.create')); ?>" class="btn btn-sm btn-outline-primary">ایجاد اسلایدر</a>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>عنوان</th>
                <th>متن</th>
                <th>عنوان لینک</th>
                <th>آدرس لینک</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($slider->title); ?></td>
                    <td><?php echo e($slider->body); ?></td>
                    <td><?php echo e($slider->link_title); ?></td>
                    <td class="dir-ltr"><?php echo e($slider->link_address); ?></td>
                    <td>
                        <div class="d-flex">
                            <a href="<?php echo e(route('slider.edit', ['slider' => $slider->id])); ?>" class="btn btn-sm btn-outline-info me-2">ویرایش</a>
                            <form action="<?php echo e(route('slider.destroy', ['slider' => $slider->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">حذف</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-admin-panel\lara-admin\resources\views/sliders/index.blade.php ENDPATH**/ ?>