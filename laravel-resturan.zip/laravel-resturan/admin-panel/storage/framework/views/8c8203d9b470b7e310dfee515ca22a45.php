<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('content'); ?>
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="fw-bold">بخش درباره ما</h4>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>عنوان</th>
                <th>متن</th>
                <th>لینک</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><?php echo e($item->title); ?></td>
                <td><?php echo e($item->body); ?></td>
                <td class="dir-ltr"><?php echo e($item->link); ?></td>
                <td>
                    <a href="<?php echo e(route('about.edit', ['about' => $item->id])); ?>"
                       class="btn btn-sm btn-outline-info me-2">ویرایش</a>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-admin-panel\lara-admin\resources\views/about/index.blade.php ENDPATH**/ ?>