<section class="food_section layout_padding-bottom">
    <div class="container" x-data="{ tab: 1 }">
        <div class="heading_container heading_center">
            <h2>
                منو محصولات
            </h2>
        </div>

        <ul class="filters_menu">
            <li :class="tab === 1 ? 'active' : ''" @click="tab = 1">برگر</li>
            <li :class="tab === 2 ? 'active' : ''" @click="tab = 2">پیتزا</li>
            <li :class="tab === 3 ? 'active' : ''" @click="tab = 3">پیش غذا و سالاد</li>
        </ul>

        <?php
            $burgers = App\Models\Product::where('category_id', 1)
                ->where('quantity', '>', 0)
                ->where('status', 1)
                ->take(3)
                ->get();
            $pizzas = App\Models\Product::where('category_id', 2)
                ->where('quantity', '>', 0)
                ->where('status', 1)
                ->take(3)
                ->get();
            $salads = App\Models\Product::where('category_id', 3)
                ->where('quantity', '>', 0)
                ->where('status', 1)
                ->take(3)
                ->get();
        ?>

        <div class="filters-content">
            <div x-show="tab === 1">
                <div class="row grid">
                    <?php $__currentLoopData = $burgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $burger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-lg-4">
                            <div class="box">
                                <div>
                                    <div class="img-box">
                                        <img class="img-fluid" src="<?php echo e(imageUrl($burger->primary_image)); ?>"
                                             alt="">
                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            <a href="<?php echo e(route('product.show', ['product' => $burger->slug])); ?>">
                                                <?php echo e($burger->name); ?>

                                            </a>
                                        </h5>
                                        <p>
                                            <?php echo e($burger->description); ?>

                                        </p>

                                        <div class="options">
                                            <?php if($burger->is_sale): ?>
                                                <h6>
                                                    <del><?php echo e(number_format($burger->price)); ?></del>
                                                    <span>
                                                        <span
                                                            class="text-danger">(<?php echo e(salePercent($burger->price, $burger->sale_price)); ?>%)</span>
                                                        <?php echo e(number_format($burger->sale_price)); ?>

                                                        <span>تومان</span>
                                                    </span>
                                                </h6>
                                            <?php else: ?>
                                                <h6>
                                                    <?php echo e(number_format($burger->price)); ?>

                                                    <span>تومان</span>
                                                </h6>
                                            <?php endif; ?>

                                            <div class="d-flex">
                                                <a class="me-2" href="<?php echo e(route('cart.increment', ['product_id' => $burger->id , 'qty' => 1])); ?>">
                                                    <i class="bi bi-cart-fill text-white fs-6"></i>
                                                </a>
                                                <a href="<?php echo e(route('profile.wishlist.add', ['product_id' => $burger->id ])); ?>">
                                                    <i class="bi bi-heart-fill text-white fs-6"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div x-show="tab === 2">
                <div class="row grid">
                    <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-lg-4">
                            <div class="box">
                                <div>
                                    <div class="img-box">
                                        <img class="img-fluid" src="<?php echo e(imageUrl($pizza->primary_image)); ?>"
                                             alt="">
                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            <a href="<?php echo e(route('product.show', ['product' => $pizza->slug])); ?>">
                                                <?php echo e($pizza->name); ?>

                                            </a>
                                        </h5>
                                        <p>
                                            <?php echo e($pizza->description); ?>

                                        </p>

                                        <div class="options">
                                            <?php if($pizza->is_sale): ?>
                                                <h6>
                                                    <del><?php echo e(number_format($pizza->price)); ?></del>
                                                    <span>
                                                        <span
                                                            class="text-danger">(<?php echo e(salePercent($pizza->price, $pizza->sale_price)); ?>%)</span>
                                                        <?php echo e(number_format($pizza->sale_price)); ?>

                                                        <span>تومان</span>
                                                    </span>
                                                </h6>
                                            <?php else: ?>
                                                <h6>
                                                    <?php echo e(number_format($pizza->price)); ?>

                                                    <span>تومان</span>
                                                </h6>
                                            <?php endif; ?>

                                            <div class="d-flex">
                                                <a class="me-2" href="<?php echo e(route('cart.increment', ['product_id' => $pizza->id , 'qty' => 1])); ?>">
                                                    <i class="bi bi-cart-fill text-white fs-6"></i>
                                                </a>
                                                <a href="<?php echo e(route('profile.wishlist.add', ['product_id' => $pizza->id ])); ?>">
                                                    <i class="bi bi-heart-fill text-white fs-6"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div x-show="tab === 3">
                <div class="row grid">
                    <?php $__currentLoopData = $salads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-lg-4">
                            <div class="box">
                                <div>
                                    <div class="img-box">
                                        <img class="img-fluid" src="<?php echo e(imageUrl($salad->primary_image)); ?>"
                                             alt="">
                                    </div>
                                    <div class="detail-box">
                                        <h5>
                                            <a href="<?php echo e(route('product.show', ['product' => $salad->slug])); ?>">
                                                <?php echo e($salad->name); ?>

                                            </a>
                                        </h5>
                                        <p>
                                            <?php echo e($salad->description); ?>

                                        </p>

                                        <div class="options">
                                            <?php if($salad->is_sale): ?>
                                                <h6>
                                                    <del><?php echo e(number_format($salad->price)); ?></del>
                                                    <span>
                                                        <span
                                                            class="text-danger">(<?php echo e(salePercent($salad->price, $salad->sale_price)); ?>%)</span>
                                                        <?php echo e(number_format($salad->sale_price)); ?>

                                                        <span>تومان</span>
                                                    </span>
                                                </h6>
                                            <?php else: ?>
                                                <h6>
                                                    <?php echo e(number_format($salad->price)); ?>

                                                    <span>تومان</span>
                                                </h6>
                                            <?php endif; ?>

                                            <div class="d-flex">
                                                <a class="me-2" href="<?php echo e(route('cart.increment', ['product_id' => $salad->id , 'qty' => 1])); ?>">
                                                    <i class="bi bi-cart-fill text-white fs-6"></i>
                                                </a>
                                                <a href="<?php echo e(route('profile.wishlist.add', ['product_id' => $salad->id ])); ?>">
                                                    <i class="bi bi-heart-fill text-white fs-6"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="btn-box">
            <a href="">
                مشاهده بیشتر
            </a>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/home/products.blade.php ENDPATH**/ ?>