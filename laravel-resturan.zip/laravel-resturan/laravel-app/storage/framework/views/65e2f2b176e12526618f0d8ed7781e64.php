<?php
    $features = App\Models\Feature::all();
?>


<section class="card-area layout_padding">
    <div class="container">
        <div class="row gy-5">
            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6 col-xs-6">
                    <div class="card text-center">
                        <div class="card-body">
                            <div class="card-icon-wrapper">
                                <i class="bi <?php echo e($feature->icon); ?> fs-2 text-white card-icon"></i>
                            </div>
                            <p class="card-text fw-bold"><?php echo e($feature->title); ?></p>
                            <p class="card-text"><?php echo e($feature->body); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/home/features.blade.php ENDPATH**/ ?>