<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="fw-bold">پیام های ارتباط با ما</h4>
    </div>

    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>نام</th>
                <th>ایمیل</th>
                <th>موضوع پیام</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($message->name); ?></td>
                    <td><?php echo e($message->email); ?></td>
                    <td><?php echo e($message->subject); ?></td>
                    <td>
                        <div class="d-flex">
                            <a href="<?php echo e(route('contact.show', ['contact' => $message->id])); ?>"
                               class="btn btn-sm btn-outline-info me-2">نمایش</a>

                            <form action="<?php echo e(route('contact.destroy', ['contact' => $message->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger" type="submit">حذف</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-admin-panel\lara-admin\resources\views/contact/index.blade.php ENDPATH**/ ?>