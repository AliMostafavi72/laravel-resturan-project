<footer class="footer_section">
    <div class="container">
        <?php
            $footer = App\Models\Footer::first();
        ?>
        <div class="row">
            <div class="col-md-4 footer-col">
                <div class="footer_contact">
                    <h4>
                        تماس با ما
                    </h4>
                    <div class="contact_link_box">
                        <a href="">
                            <i class="bi bi-geo-alt-fill"></i>
                            <span>
                                <?php echo e($footer->contact_address); ?>

                            </span>
                        </a>
                        <a href="">
                            <div class="d-flex justify-content-center">
                                <i class="bi bi-telephone-fill" aria-hidden="true"></i>
                                <p class="my-0" style="direction: ltr;">
                                    <?php echo e($footer->contact_phone); ?>

                                </p>
                            </div>
                        </a>
                        <a href="">
                            <i class="bi bi-envelope-fill"></i>
                            <span>
                                <?php echo e($footer->contact_email); ?>

                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 footer-col">
                <div class="footer_detail">
                    <a href="" class="footer-logo">
                        <?php echo e($footer->title); ?>

                    </a>
                    <p>
                        <?php echo e($footer->body); ?>

                    </p>
                    <div class="footer_social">
                        <?php if($footer->telegram_link !== null): ?>
                            <a href="<?php echo e($footer->telegram_link); ?>">
                                <i class="bi bi-telegram"></i>
                            </a>
                        <?php endif; ?>
                        <?php if($footer->whatsapp_link !== null): ?>
                            <a href="<?php echo e($footer->whatsapp_link); ?>">
                                <i class="bi bi-whatsapp"></i>
                            </a>
                        <?php endif; ?>
                        <?php if($footer->instagram_link !== null): ?>
                            <a href="<?php echo e($footer->instagram_link); ?>">
                                <i class="bi bi-instagram"></i>
                            </a>
                        <?php endif; ?>
                        <?php if($footer->youtube_link !== null): ?>
                            <a href="<?php echo e($footer->youtube_link); ?>">
                                <i class="bi bi-youtube"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4 footer-col">
                <h4>
                    ساعت کاری
                </h4>
                <p>
                    <?php echo e($footer->work_days); ?>

                </p>
                <p>
                    <?php echo e($footer->work_hour_from); ?> صبح تا <?php echo e($footer->work_hour_to); ?> شب
                </p>
            </div>
        </div>
        <div class="footer-info">
            <p>
                <?php echo e($footer->copyright); ?>

            </p>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-right',
        iconColor: 'white',
        customClass: {
            popup: 'colored-toast',
        },
        showConfirmButton: false,
        timer: 5000,
        timerProgressBar: true,
    })

    <?php if(session('success')): ?>
    Toast.fire({
        icon: 'success',
        title: '<?php echo e(session('success')); ?>',
    })
    <?php elseif(session('error')): ?>
    Toast.fire({
        icon: 'error',
        title: '<?php echo e(session('error')); ?>',
    })
    <?php elseif(session('warning')): ?>
    Toast.fire({
        icon: 'warning',
        title: '<?php echo e(session('warning')); ?>',
    })
    <?php endif; ?>
</script>

<?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH C:\Users\Ali\PhpstormProjects\restaurant-webprog\resturan-lara\laravel-app\resources\views/layout/footer.blade.php ENDPATH**/ ?>